import sys
import os
import json
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                            QHBoxLayout, QLabel, QLineEdit, QPushButton, 
                            QTextEdit, QComboBox, QFileDialog, QGroupBox,
                            QCheckBox, QProgressBar, QMessageBox)
from PyQt5.QtCore import QThread, pyqtSignal, QProcess
from PyQt5.QtGui import QFont, QTextCursor
import subprocess

class DownloadThread(QThread):
    # Signals to communicate with main thread
    progress = pyqtSignal(str)
    finished = pyqtSignal()
    error = pyqtSignal(str)
    
    def __init__(self, url, options):
        super().__init__()
        self.url = url
        self.options = options
        self.process = None
        
    def run(self):
        try:
            # Build command
            cmd = ['yt-dlp']
            
            # Add format option
            if self.options.get('format'):
                cmd.extend(['-f', self.options['format']])
            
            # Add output path
            if self.options.get('output_path'):
                output_template = os.path.join(self.options['output_path'], '%(title)s.%(ext)s')
                cmd.extend(['-o', output_template])
            
            # Add audio only option
            if self.options.get('audio_only'):
                cmd.extend(['-x', '--audio-format', 'mp3'])
            
            # Add subtitle option
            if self.options.get('subtitles'):
                cmd.extend(['--write-sub', '--sub-lang', 'en'])
            
            # Add URL
            cmd.append(self.url)
            
            # Create process
            self.process = QProcess()
            self.process.readyReadStandardOutput.connect(self.handle_output)
            self.process.readyReadStandardError.connect(self.handle_error)
            
            # Start process
            self.process.start(cmd[0], cmd[1:])
            self.process.waitForFinished(-1)
            
            if self.process.exitCode() == 0:
                self.progress.emit("\n✅ Download completed successfully!")
            else:
                self.error.emit("Download failed with exit code: " + str(self.process.exitCode()))
                
        except Exception as e:
            self.error.emit(f"Error: {str(e)}")
        finally:
            self.finished.emit()
    
    def handle_output(self):
        data = self.process.readAllStandardOutput().data().decode('utf-8')
        self.progress.emit(data)
    
    def handle_error(self):
        data = self.process.readAllStandardError().data().decode('utf-8')
        self.progress.emit(data)
    
    def stop(self):
        if self.process and self.process.state() != QProcess.NotRunning:
            self.process.terminate()
            if not self.process.waitForFinished(5000):
                self.process.kill()

class YTDLPGui(QMainWindow):
    def __init__(self):
        super().__init__()
        self.download_thread = None
        self.init_ui()
        self.check_ytdlp()
        
    def init_ui(self):
        self.setWindowTitle('yt-dlp GUI v1.0')
        self.setGeometry(100, 100, 800, 600)
        
        # Create central widget and layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        
        # URL input section
        url_group = QGroupBox("Video URL")
        url_layout = QHBoxLayout()
        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("Enter YouTube URL here...")
        url_layout.addWidget(self.url_input)
        url_group.setLayout(url_layout)
        layout.addWidget(url_group)
        
        # Options section
        options_group = QGroupBox("Download Options")
        options_layout = QVBoxLayout()
        
        # Format selection
        format_layout = QHBoxLayout()
        format_layout.addWidget(QLabel("Quality:"))
        self.format_combo = QComboBox()
        self.format_combo.addItems([
            "best - Best quality",
            "worst - Worst quality",
            "bestaudio - Best audio",
            "1080p - 1080p",
            "720p - 720p",
            "480p - 480p",
            "360p - 360p"
        ])
        format_layout.addWidget(self.format_combo)
        format_layout.addStretch()
        options_layout.addLayout(format_layout)
        
        # Audio only checkbox
        self.audio_only_checkbox = QCheckBox("Extract audio only (MP3)")
        options_layout.addWidget(self.audio_only_checkbox)
        
        # Subtitles checkbox
        self.subtitles_checkbox = QCheckBox("Download subtitles")
        options_layout.addWidget(self.subtitles_checkbox)
        
        # Output path selection
        path_layout = QHBoxLayout()
        path_layout.addWidget(QLabel("Save to:"))
        self.path_input = QLineEdit()
        self.path_input.setText(os.path.expanduser("~/Downloads"))
        path_layout.addWidget(self.path_input)
        self.browse_button = QPushButton("Browse")
        self.browse_button.clicked.connect(self.browse_folder)
        path_layout.addWidget(self.browse_button)
        options_layout.addLayout(path_layout)
        
        options_group.setLayout(options_layout)
        layout.addWidget(options_group)
        
        # Control buttons
        button_layout = QHBoxLayout()
        self.download_button = QPushButton("Download")
        self.download_button.clicked.connect(self.start_download)
        self.download_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        
        self.stop_button = QPushButton("Stop")
        self.stop_button.clicked.connect(self.stop_download)
        self.stop_button.setEnabled(False)
        self.stop_button.setStyleSheet("""
            QPushButton {
                background-color: #f44336;
                color: white;
                font-weight: bold;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #da190b;
            }
            QPushButton:disabled {
                background-color: #cccccc;
            }
        """)
        
        button_layout.addWidget(self.download_button)
        button_layout.addWidget(self.stop_button)
        button_layout.addStretch()
        layout.addLayout(button_layout)
        
        # Progress/Output section
        output_group = QGroupBox("Output")
        output_layout = QVBoxLayout()
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Consolas", 9))
        output_layout.addWidget(self.output_text)
        output_group.setLayout(output_layout)
        layout.addWidget(output_group)
        
    def check_ytdlp(self):
        """Check if yt-dlp is installed"""
        try:
            subprocess.run(['yt-dlp', '--version'], 
                         capture_output=True, check=True)
            self.output_text.append("✓ yt-dlp is installed and ready\n")
        except (subprocess.CalledProcessError, FileNotFoundError):
            QMessageBox.warning(self, "yt-dlp not found", 
                              "yt-dlp is not installed. Please install it using:\n\n"
                              "pip install yt-dlp\n\n"
                              "or download from https://github.com/yt-dlp/yt-dlp")
    
    def browse_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Download Folder")
        if folder:
            self.path_input.setText(folder)
    
    def start_download(self):
        url = self.url_input.text().strip()
        if not url:
            QMessageBox.warning(self, "No URL", "Please enter a URL")
            return
        
        # Prepare options
        options = {
            'format': self.format_combo.currentText().split(' - ')[0],
            'output_path': self.path_input.text(),
            'audio_only': self.audio_only_checkbox.isChecked(),
            'subtitles': self.subtitles_checkbox.isChecked()
        }
        
        # Clear output
        self.output_text.clear()
        self.output_text.append(f"Starting download: {url}\n")
        
        # Disable download button, enable stop button
        self.download_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        
        # Create and start download thread
        self.download_thread = DownloadThread(url, options)
        self.download_thread.progress.connect(self.update_output)
        self.download_thread.finished.connect(self.download_finished)
        self.download_thread.error.connect(self.download_error)
        self.download_thread.start()
    
    def stop_download(self):
        if self.download_thread and self.download_thread.isRunning():
            self.output_text.append("\n⚠️ Stopping download...")
            self.download_thread.stop()
    
    def update_output(self, text):
        self.output_text.insertPlainText(text)
        # Auto-scroll to bottom
        cursor = self.output_text.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.output_text.setTextCursor(cursor)
    
    def download_finished(self):
        self.download_button.setEnabled(True)
        self.stop_button.setEnabled(False)
    
    def download_error(self, error_msg):
        self.output_text.append(f"\n❌ Error: {error_msg}")
        QMessageBox.critical(self, "Download Error", error_msg)
    
    def closeEvent(self, event):
        if self.download_thread and self.download_thread.isRunning():
            reply = QMessageBox.question(self, 'Close Application',
                                       'A download is in progress. Are you sure you want to exit?',
                                       QMessageBox.Yes | QMessageBox.No,
                                       QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.download_thread.stop()
                self.download_thread.wait()
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()

def main():
    app = QApplication(sys.argv)
    window = YTDLPGui()
    window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()

